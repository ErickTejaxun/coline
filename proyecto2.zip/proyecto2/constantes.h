#ifndef CONSTANTES_H
#define CONSTANTES_H
#include <qstring.h>

class constantes
{
public:
    constantes();
    static QString d0 ;  // Asignacion normal
    static QString d1 ;
    static QString d2 ;
    static QString d3 ;
};

#endif // CONSTANTES_H
