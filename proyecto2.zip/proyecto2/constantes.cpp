#include "constantes.h"



constantes::constantes()
{

}
